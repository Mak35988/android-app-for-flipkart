package com.example.flikartgrid;

//public interface ItemClickListener {
//}


public interface ItemClickListener {
    void onClick(int position);
}
