package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class RepositoryDetails extends AppCompatActivity {

    TextView textView,textView1,textView2;

    Button button,button1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repository_details);
        
        textView= findViewById(R.id.project_name);
        textView1= findViewById(R.id.project_description);
        textView2= findViewById(R.id.project_language);

        button=findViewById(R.id.viewproject);
        button1=findViewById(R.id.testproject);




        Intent intent = getIntent();

        String str = intent.getStringExtra("message_key");
        String str1 = intent.getStringExtra("message_key1");
        String str2 = intent.getStringExtra("message_key2");


        textView.setText(str);

        if(str1.isEmpty()){
            textView1.setText("No Description provide related to the project");
        }

        else{
            textView1.setText(str1);
        }



        if(str2.isEmpty()){
            textView2.setText("No Specific Language used in related to the project");
        }

        else{
            textView2.setText(str2);
        }



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(RepositoryDetails.this,showprojectongithubbywebview.class);

                intent.putExtra("project name", str);
                startActivity(intent);
            }
        });



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(RepositoryDetails.this,TestingProject.class);
                intent.putExtra("project name", str);
                startActivity(intent);
            }
        });




    }






}






