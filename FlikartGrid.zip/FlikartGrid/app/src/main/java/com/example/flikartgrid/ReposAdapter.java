package com.example.flikartgrid;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//public class ReposAdapter extends RecyclerView.Adapter {
//    public ReposAdapter(List<GitHubRepo> myDataSource, int list_item_repo, Object applicationContext) {
//    }
//}



import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

public class ReposAdapter extends RecyclerView.Adapter<ReposAdapter.ReposViewHolder> {

    private List<GitHubRepo> repos;
    private int rowLayout;
    private Context context;

    ///////////////////////////////////

    ItemClickListener itemClickListener;
    int selectedPosition=-1;


    // create constructor
    public ReposAdapter(List<GitHubRepo> repos, ItemClickListener itemClickListener)
    {
        this.setRepos(repos);
        this.itemClickListener=itemClickListener;
    }



    ///////////////////////////////////////////////


    public ReposAdapter(List<GitHubRepo> repos, int rowLayout, Context context) {
        this.setRepos(repos);
        this.setRowLayout(rowLayout);
        this.setContext(context);
    }

    public List<GitHubRepo> getRepos() {
        return repos;
    }

    public void setRepos(List<GitHubRepo> repos) {
        this.repos = repos;
    }

    public int getRowLayout() {
        return rowLayout;
    }

    public void setRowLayout(int rowLayout) {
        this.rowLayout = rowLayout;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public static class ReposViewHolder extends RecyclerView.ViewHolder {
        LinearLayout reposLayout;
        TextView repoName;
        TextView repoDescription;
        TextView repolanguage;


        public ReposViewHolder(View v) {
            super(v);
            reposLayout = (LinearLayout) v.findViewById(R.id.repo_item_layout);
            repoName = (TextView) v.findViewById(R.id.repoName);
            repoDescription = (TextView) v.findViewById(R.id.repoDescription);
            repolanguage = (TextView) v.findViewById(R.id.repoLanguage);
        }
    }


    @Override
    public ReposAdapter.ReposViewHolder onCreateViewHolder(ViewGroup parent,
                                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);


    //    Toast.makeText(getContext(), ""+getItemCount(), Toast.LENGTH_SHORT).show();



        return new ReposViewHolder(view);
    }




    @Override
    public void onBindViewHolder(ReposViewHolder holder, final int position) {
        holder.repoName.setText(repos.get(position).getName());
        holder.repoDescription.setText(repos.get(position).getDescription());
        holder.repolanguage.setText(repos.get(position).getLanguage());



        ///////////////////////////////////////////////////


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get adapter position
                int position=holder.getAdapterPosition();
                // call listener

//
                String jj=  holder.repoName.getText().toString();

                String jj1=  holder.repoDescription.getText().toString();

                String jj2=  holder.repolanguage.getText().toString();



           //     Toast.makeText(getContext(), ""+position+ "   " + jj , Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getContext(), RepositoryDetails.class);

                i.putExtra("message_key", jj);
                i.putExtra("message_key1", jj1);
                i.putExtra("message_key2", jj2);

                getContext().startActivity(i);




                notifyDataSetChanged();
            }
        });










        ///////////////////////////////////////////








    }

    @Override
    public int getItemCount() {

        return repos.size();
    }


}