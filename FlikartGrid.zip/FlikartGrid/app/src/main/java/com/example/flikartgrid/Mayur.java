package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

public class Mayur extends AppCompatActivity {

    private Button storage, camera;
    TextView fileformat;
    ImageView imageView;



    private static final int CAMERA_PERMISSION_CODE = 100;
    private static final int STORAGE_PERMISSION_CODE = 101;



    Button uploadv;
    ProgressDialog progressDialog;


    ImageView upload;
    Uri imageuri = null;




    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mayur);

        checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);


        fileformat = findViewById(R.id.fileformat);

        imageView= findViewById(R.id.imageview);



//        uploadv = findViewById(R.id.uploadv);
//        uploadv.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
                // Code for showing progressDialog while uploading


                progressDialog = new ProgressDialog(Mayur.this);
                choosevideo();
//            }
//        });



    }




    // choose a video from phone storage
    private void choosevideo() {
        Intent intent = new Intent();

        // for video type ///////////

//        intent.setType("video/*");

        /// for pdf type
//
//        intent.setType("application/pdf");


        ///////// for all type


        intent.setType("*/*");


        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(intent, 5);
    }

    Uri videouri;

    // startActivityForResult is used to receive the result, which is the selected video.
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 5 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            videouri = data.getData();

            progressDialog.setTitle("Uploading...");
            progressDialog.show();


//            uploadvideo();


//            Toast.makeText(this, ""+getfiletype(videouri), Toast.LENGTH_SHORT).show();


//            String[] fileextension= {"cpp", "py", "exe", "bat", "apk","java"};


            String[] fileextension= {};



            int x=0;

            for(int i=0;i<fileextension.length;i++){

                String s=getfiletype(videouri);//Now it will return "10"

                if(fileextension[i].equals(s)){
                    x=1;
                    Toast.makeText(this, ""+getfiletype(videouri), Toast.LENGTH_SHORT).show();
                }

//                Toast.makeText(this, ""+s +"   "+ fileextension[i] + "  "+ ((Object)getfiletype(videouri)).getClass().getSimpleName(), Toast.LENGTH_SHORT).show();

            }



            if(x==1){
                fileformat.setVisibility(View.VISIBLE);
                progressDialog.hide();
                imageView.setVisibility(View.VISIBLE);
                Toast.makeText(this, "File format does not support by us", Toast.LENGTH_SHORT).show();
            }



            else{
                            uploadvideo();


            }

        }
    }





    private String getfiletype(Uri videouri) {
        ContentResolver r = getContentResolver();
        // get the file type ,in this case its mp4
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(r.getType(videouri));

    }



    private void uploadvideo() {
        if (videouri != null) {
            // save the selected video in Firebase storage
            final StorageReference reference = FirebaseStorage.getInstance().getReference("Files/" + System.currentTimeMillis() + "." + getfiletype(videouri));
            reference.putFile(videouri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                    while (!uriTask.isSuccessful()) ;
                    // get the link of video
                    String downloadUri = uriTask.getResult().toString();
                    DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("Video");
                    HashMap<String, String> map = new HashMap<>();


                    map.put("repolink", downloadUri);

                    /////////////////////////////////////////////////


                    Intent intent = getIntent();
                    String str = intent.getStringExtra("message_key");


                    map.put("reponame", str);



                    reference1.child("" + System.currentTimeMillis()).setValue(map);
                    // Video uploaded successfully
                    // Dismiss dialog
                    progressDialog.dismiss();
                    Toast.makeText(Mayur.this, "Repository Uploaded Succesfully!!", Toast.LENGTH_SHORT).show();

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    // Error, Image not uploaded
                    progressDialog.dismiss();
                    Toast.makeText(Mayur.this, "Failed ", Toast.LENGTH_SHORT).show();

//
//                    Intent intent = new Intent(Mayur.this, SecondFragment.class);
//                    startActivity(intent);

                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                // Progress Listener for loading
                // percentage on the dialog box
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    // show the progress bar
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                    progressDialog.setMessage("Uploaded " + (int) progress + "%");
                }
            });
        }
    }







    /////////////////////////////////////////////////




    // Function to check and request permission.
    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(Mayur.this, permission) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(Mayur.this, new String[] { permission }, requestCode);
        }
        else {
            Toast.makeText(Mayur.this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(Mayur.this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Mayur.this, "Storage Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
