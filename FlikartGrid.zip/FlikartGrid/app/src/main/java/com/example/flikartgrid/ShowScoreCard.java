package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class ShowScoreCard extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_score_card);


        ////////////
        Intent intent = getIntent();

        String str = intent.getStringExtra("project name");



        button=findViewById(R.id.vulnerability);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(ShowScoreCard.this,Vulnerability.class);
                intent.putExtra("project name", str);
                startActivity(intent);


            }
        });




    }
}