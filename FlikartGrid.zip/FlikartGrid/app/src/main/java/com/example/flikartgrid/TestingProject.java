package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class TestingProject extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing_project);




        ////////////
        Intent intent = getIntent();

        String str = intent.getStringExtra("project name");

        String url="https://github.com/Mak35988/"+str+"/new/master?filename=.github%2Fworkflows%2Fcodeql.yml&workflow_template=codeql";

//        String url="https://github.com/Mak35988/"+str+"/actions/new?category=security";



        WebView w = (WebView) findViewById(R.id.web);

        w.loadUrl(""+url);



        w.getSettings().setJavaScriptEnabled(true);

        w.setWebViewClient(new WebViewClient());




        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {

//                Intent intent= new Intent(TestingProject.this,ShowScoreCard.class);

                Intent intent= new Intent(TestingProject.this,WaitingProcess.class);


                intent.putExtra("project name", str);
                startActivity(intent);


                //do what you want
            }
        }, 60000);


    }
}