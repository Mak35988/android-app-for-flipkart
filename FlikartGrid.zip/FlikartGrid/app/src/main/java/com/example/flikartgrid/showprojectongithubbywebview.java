package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class showprojectongithubbywebview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showprojectongithubbywebview);

        ////////////
        Intent intent = getIntent();

        String str = intent.getStringExtra("project name");

        String url="https://github.com/Mak35988/"+str;

        ///////////


        WebView w = (WebView) findViewById(R.id.web);

//        w.loadUrl("http://www.google.com");

        w.loadUrl(""+url);



        // this will enable the javascript.
        w.getSettings().setJavaScriptEnabled(true);

        // WebViewClient allows you to handle
        // onPageFinished and override Url loading.
        w.setWebViewClient(new WebViewClient());



    }
}