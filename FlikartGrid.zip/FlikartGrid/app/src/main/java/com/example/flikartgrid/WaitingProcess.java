package com.example.flikartgrid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WaitingProcess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting_process);







        ////////////
        Intent intent = getIntent();

        String str = intent.getStringExtra("project name");

        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {

//                Intent intent= new Intent(TestingProject.this,ShowScoreCard.class);

                Intent intent= new Intent(WaitingProcess.this,ShowScoreCard.class);


                intent.putExtra("project name", str);
                startActivity(intent);


                //do what you want
            }
        }, 60000);








    }
}